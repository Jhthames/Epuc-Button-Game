class Song < ApplicationRecord
  belongs_to :user
  has_many :users, through: :playlist
  has_many :playlist

  validates :title, :artist, presence: true, length: { minimum: 2 }
end
