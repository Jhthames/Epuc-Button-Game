class User < ApplicationRecord
  
  has_many :songs, through: :playlist
  has_many :playlist

  email_regex = /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]+)\z/i
  validates :first_name, :last_name, :email, presence: true
  validates :email, format: { with: email_regex }, uniqueness: { case_sensitive: false }, confirmation: true
  validates :password, length: { minimum: 4 }, allow_nil: true
end
