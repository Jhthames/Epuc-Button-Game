class PlaylistsController < ApplicationController
    def create
        if !(Song.find(params[:song_id]).users.include?(User.find(current_user.id)))
            @playlist = Playlist.create(user: User.find(params[:user_id]), song: Song.find(params[:song_id]))
        end
        redirect_to '/songs'
    end
end
