Rails.application.routes.draw do
  root 'sessions#index'
  post '/users/new' => 'users#create'
  get '/users/:id' => 'users#show'

  get '/songs' => 'songs#index'
  post '/songs' => 'songs#create'
  post '/songs/addexisting' => 'songs#addexisting'
  get '/songs/:id' => 'songs#show'

  post '/sessions' => 'sessions#create'
  get '/sessions/destroy' => 'sessions#destroy'
  
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
