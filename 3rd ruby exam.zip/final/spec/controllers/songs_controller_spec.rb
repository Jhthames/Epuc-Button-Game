require 'rails_helper'

RSpec.describe SongsController, type: :controller do

end
