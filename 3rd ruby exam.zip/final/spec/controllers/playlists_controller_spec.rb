require 'rails_helper'

RSpec.describe PlaylistsController, type: :controller do

end
