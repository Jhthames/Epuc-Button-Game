FactoryBot.define do
  factory :playlist do
    user { nil }
    song { nil }
  end
end
