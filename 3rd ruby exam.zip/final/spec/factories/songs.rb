FactoryBot.define do
  factory :song do
    title { "MyString" }
    artist { "MyString" }
    user { nil }
  end
end
